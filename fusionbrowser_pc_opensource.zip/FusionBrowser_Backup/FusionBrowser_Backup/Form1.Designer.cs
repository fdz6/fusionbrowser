﻿namespace FusionBrowser_Backup
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Topbar = new Panel();
            MinimizeBTN = new Button();
            MaximizeBTN = new Button();
            ExitBTNNow = new Button();
            Title = new Label();
            webView21 = new Microsoft.Web.WebView2.WinForms.WebView2();
            BackBTN = new Button();
            ForwardBTN = new Button();
            RefreshBTN = new Button();
            SearchBox = new TextBox();
            OptionBTN = new Button();
            Topbar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)webView21).BeginInit();
            SuspendLayout();
            // 
            // Topbar
            // 
            Topbar.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Topbar.BackColor = Color.FromArgb(35, 35, 35);
            Topbar.Controls.Add(MinimizeBTN);
            Topbar.Controls.Add(MaximizeBTN);
            Topbar.Controls.Add(ExitBTNNow);
            Topbar.Controls.Add(Title);
            Topbar.Location = new Point(-2, -1);
            Topbar.Name = "Topbar";
            Topbar.Size = new Size(1156, 47);
            Topbar.TabIndex = 0;
            Topbar.Paint += Topbar_Paint;
            // 
            // MinimizeBTN
            // 
            MinimizeBTN.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            MinimizeBTN.BackColor = Color.FromArgb(35, 35, 35);
            MinimizeBTN.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MinimizeBTN.ForeColor = Color.White;
            MinimizeBTN.Location = new Point(1015, 5);
            MinimizeBTN.Name = "MinimizeBTN";
            MinimizeBTN.Size = new Size(42, 39);
            MinimizeBTN.TabIndex = 4;
            MinimizeBTN.Text = "–";
            MinimizeBTN.UseVisualStyleBackColor = false;
            MinimizeBTN.Click += MinimizeBTN_Click_1;
            // 
            // MaximizeBTN
            // 
            MaximizeBTN.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            MaximizeBTN.BackColor = Color.FromArgb(35, 35, 35);
            MaximizeBTN.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            MaximizeBTN.ForeColor = Color.White;
            MaximizeBTN.Location = new Point(1063, 5);
            MaximizeBTN.Name = "MaximizeBTN";
            MaximizeBTN.Size = new Size(42, 39);
            MaximizeBTN.TabIndex = 3;
            MaximizeBTN.Text = "🗖";
            MaximizeBTN.UseVisualStyleBackColor = false;
            MaximizeBTN.Click += MaximizeBTN_Click_1;
            // 
            // ExitBTNNow
            // 
            ExitBTNNow.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            ExitBTNNow.BackColor = Color.FromArgb(35, 35, 35);
            ExitBTNNow.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ExitBTNNow.ForeColor = Color.White;
            ExitBTNNow.Location = new Point(1111, 5);
            ExitBTNNow.Name = "ExitBTNNow";
            ExitBTNNow.Size = new Size(42, 39);
            ExitBTNNow.TabIndex = 2;
            ExitBTNNow.Text = "X";
            ExitBTNNow.UseVisualStyleBackColor = false;
            ExitBTNNow.Click += ExitBTNNow_Click_1;
            // 
            // Title
            // 
            Title.AutoSize = true;
            Title.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Title.ForeColor = Color.White;
            Title.Location = new Point(14, 5);
            Title.Name = "Title";
            Title.Size = new Size(189, 32);
            Title.TabIndex = 0;
            Title.Text = "Fusion Browser";
            // 
            // webView21
            // 
            webView21.AllowExternalDrop = true;
            webView21.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            webView21.CreationProperties = null;
            webView21.DefaultBackgroundColor = Color.White;
            webView21.Location = new Point(-2, 99);
            webView21.Name = "webView21";
            webView21.Size = new Size(1156, 458);
            webView21.Source = new Uri("https://search.brave.com", UriKind.Absolute);
            webView21.TabIndex = 1;
            webView21.ZoomFactor = 1D;
            webView21.Click += webView21_Click;
            // 
            // BackBTN
            // 
            BackBTN.BackColor = Color.FromArgb(35, 35, 35);
            BackBTN.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BackBTN.ForeColor = Color.White;
            BackBTN.Location = new Point(12, 52);
            BackBTN.Name = "BackBTN";
            BackBTN.Size = new Size(42, 39);
            BackBTN.TabIndex = 5;
            BackBTN.Text = "<";
            BackBTN.UseVisualStyleBackColor = false;
            BackBTN.Click += BackBTN_Click;
            // 
            // ForwardBTN
            // 
            ForwardBTN.BackColor = Color.FromArgb(35, 35, 35);
            ForwardBTN.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ForwardBTN.ForeColor = Color.White;
            ForwardBTN.Location = new Point(60, 52);
            ForwardBTN.Name = "ForwardBTN";
            ForwardBTN.Size = new Size(42, 39);
            ForwardBTN.TabIndex = 6;
            ForwardBTN.Text = ">";
            ForwardBTN.UseVisualStyleBackColor = false;
            ForwardBTN.Click += ForwardBTN_Click_1;
            // 
            // RefreshBTN
            // 
            RefreshBTN.BackColor = Color.FromArgb(35, 35, 35);
            RefreshBTN.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RefreshBTN.ForeColor = Color.White;
            RefreshBTN.Location = new Point(108, 52);
            RefreshBTN.Name = "RefreshBTN";
            RefreshBTN.Size = new Size(42, 39);
            RefreshBTN.TabIndex = 7;
            RefreshBTN.Text = "⟳";
            RefreshBTN.UseVisualStyleBackColor = false;
            RefreshBTN.Click += RefreshBTN_Click_1;
            // 
            // SearchBox
            // 
            SearchBox.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            SearchBox.BackColor = Color.FromArgb(35, 35, 35);
            SearchBox.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SearchBox.ForeColor = Color.White;
            SearchBox.Location = new Point(156, 54);
            SearchBox.Name = "SearchBox";
            SearchBox.Size = new Size(937, 37);
            SearchBox.TabIndex = 8;
            SearchBox.TextChanged += SearchBox_TextChanged;
            // 
            // OptionBTN
            // 
            OptionBTN.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            OptionBTN.BackColor = Color.FromArgb(35, 35, 35);
            OptionBTN.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            OptionBTN.ForeColor = Color.White;
            OptionBTN.Location = new Point(1099, 53);
            OptionBTN.Name = "OptionBTN";
            OptionBTN.Size = new Size(42, 39);
            OptionBTN.TabIndex = 9;
            OptionBTN.Text = "☰";
            OptionBTN.UseVisualStyleBackColor = false;
            OptionBTN.Click += OptionBTN_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(45, 45, 45);
            ClientSize = new Size(1153, 557);
            Controls.Add(OptionBTN);
            Controls.Add(SearchBox);
            Controls.Add(RefreshBTN);
            Controls.Add(ForwardBTN);
            Controls.Add(BackBTN);
            Controls.Add(webView21);
            Controls.Add(Topbar);
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Fusion Browser";
            Topbar.ResumeLayout(false);
            Topbar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)webView21).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel Topbar;
        private Label Title;
        private Microsoft.Web.WebView2.WinForms.WebView2 webView21;
        private Button ExitBTNNow;
        private Button MaximizeBTN;
        private Button MinimizeBTN;
        private Button BackBTN;
        private Button ForwardBTN;
        private Button RefreshBTN;
        private TextBox SearchBox;
        private Button OptionBTN;
    }
}
