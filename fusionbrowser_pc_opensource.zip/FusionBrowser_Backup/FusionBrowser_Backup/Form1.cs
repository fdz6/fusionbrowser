﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

namespace FusionBrowser_Backup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeWebView();
            Topbar.Capture = true;
            Topbar.MouseDown += Topbar_MouseDown;
            Topbar.MouseMove += Topbar_MouseMove;
            Topbar.MouseUp += Topbar_MouseUp;
            Topbar.KeyDown += SearchBox_KeyDown;
            SearchBox.KeyDown += SearchBox_KeyDown;
        }

        private async void InitializeWebView()
        {
            await webView21.EnsureCoreWebView2Async(null);
            webView21.CoreWebView2.NavigationCompleted += (sender, e) => SearchBox.Text = webView21.Source.AbsoluteUri;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            webView21.Source = new Uri("https://search.brave.com");
            this.KeyPreview = true;
        }


        private void HandleEnterKey()
        {
            string input = SearchBox.Text.Trim();
            bool hasValidDomain = System.Text.RegularExpressions.Regex.IsMatch(input, @"\.[a-zA-Z]{2,}$");
            if ((input.StartsWith("www.", StringComparison.OrdinalIgnoreCase) ||
                 input.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                 input.StartsWith("https://", StringComparison.OrdinalIgnoreCase)) &&
                 hasValidDomain)
            {
                if (input.StartsWith("www.", StringComparison.OrdinalIgnoreCase) &&
                    !input.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                    !input.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                {
                    input = "https://" + input;
                }
                webView21.Source = new Uri(input);
            }
            else if (hasValidDomain &&
                     !input.StartsWith("http://", StringComparison.OrdinalIgnoreCase) &&
                     !input.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
            {
                input = "https://" + input;
                webView21.Source = new Uri(input);
            }
            else
            {
                webView21.Source = new Uri("https://search.brave.com/search?q=" + Uri.EscapeDataString(input));
            }
        }

        bool drag = false;
        int mouseX = 0;
        int mouseY = 0;
        private void Topbar_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            mouseX = Cursor.Position.X - this.Left;
            mouseY = Cursor.Position.Y - this.Top;
        }

        private void Topbar_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }

        private void Topbar_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                this.Left = Cursor.Position.X - mouseX;
                this.Top = Cursor.Position.Y - mouseY;
            }
        }

        private void OptionBTN_Click(object sender, EventArgs e)
        {

        }

        private void BackBTN_Click(object sender, EventArgs e)
        {
            webView21.GoBack();
        }

        private void ForwardBTN_Click(object sender, EventArgs e)
        {
            webView21.GoForward();
        }

        private void RefreshBTN_Click(object sender, EventArgs e)
        {
            if (webView21 != null && webView21.CoreWebView2 != null)
            {
                webView21.CoreWebView2.Reload();
            }
            else
            {
                MessageBox.Show("WebView2 is not initialized yet.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ExitBTNNow_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MaximizeBTN_Click(object sender, EventArgs e)
        {
            this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        }

        private void MinimizeBTN_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void webView21_Click(object sender, EventArgs e)
        {

        }

        private void ExitBTNNow_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MaximizeBTN_Click_1(object sender, EventArgs e)
        {
            this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        }

        private void MinimizeBTN_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void ForwardBTN_Click_1(object sender, EventArgs e)
        {
            webView21.GoForward();
        }

        private void RefreshBTN_Click_1(object sender, EventArgs e)
        {
            if (webView21 != null && webView21.CoreWebView2 != null)
            {
                webView21.CoreWebView2.Reload();
            }
            else
            {
                MessageBox.Show("WebView2 is not initialized yet.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void SearchBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SearchBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                HandleEnterKey();
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }

        private void OptionBTN_Click_1(object sender, EventArgs e)
        {
            if (OptionBTN.Text == "☰")
            {
                OptionBTN.Text = "X";
            }
            else
            {
                OptionBTN.Text = "☰";
            }
        }

        private void Topbar_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
